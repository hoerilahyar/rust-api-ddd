DROP TABLE IF EXISTS log_activities;
