pub mod event_bus;

pub use event_bus::{DomainEvent, EventBus, SharedEventBus};
